import{t as e}from"./jsx-runtime.js";import{T as t}from"./useActiveWallet-CEs8euQ3.js";import{t as n}from"./ExclamationTriangleIcon.js";var r=e(),i=({children:e,theme:t,className:i})=>(0,r.jsxs)(a,{$theme:t,className:i,children:[(0,r.jsx)(n,{width:`20px`,height:`20px`,color:`var(--privy-color-icon-warning)`,strokeWidth:2,style:{flexShrink:0}}),(0,r.jsx)(o,{$theme:t,children:e})]}),a=t.div`
  display: flex;
  gap: 0.75rem;
  background-color: var(--privy-color-warn-bg);
  align-items: flex-start;
  padding: 1rem;
  border-radius: 0.75rem;
`,o=t.div`
  color: ${e=>e.$theme===`dark`?`var(--privy-color-foreground-2)`:`var(--privy-color-foreground)`};
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  flex: 1;
  text-align: left;
`;export{i as t};